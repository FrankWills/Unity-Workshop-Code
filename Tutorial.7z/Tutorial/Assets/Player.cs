﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public float moveSpeed;
	public float rotationSpeed;
	public float attackSpeed = 4;

	public GameObject bulletPrefab;
	public Transform bulletParent;

	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update() {

		float speed = 0;
		float rotation = 0;

		if (Input.GetKey(KeyCode.UpArrow)) {
			speed = speed + moveSpeed;
		}
		if (Input.GetKey(KeyCode.DownArrow)) {
			speed = speed - moveSpeed;
		}


		if (Input.GetKey(KeyCode.LeftArrow)) {
			rotation -= rotationSpeed;
		}
		if (Input.GetKey(KeyCode.RightArrow)) {
			rotation += rotationSpeed;
		}

		this.transform.Rotate(Vector3.up, rotation * Time.deltaTime);
		this.transform.Translate(Vector3.forward * speed * Time.deltaTime);


		if (Input.GetKeyDown(KeyCode.Space)) {
			Shoot(this.transform.TransformVector(Vector3.forward), 15);
		}


		/*
		 * 
		 * 

		hypothetical health/invuln system
		float invulnEnd;
		if (hit && Time.time > invulnEnd) {
			 invulnEnd = Time.time + 3;
			DoDamage();

		if(health == 0){
			die()
		}

		}
		*/

	}

	

	private void Shoot(Vector3 dir, float speed) {

		//instiatiate object
		GameObject bullet = Instantiate(bulletPrefab);

		//set position and velocity
		bullet.transform.position = this.transform.position + dir;
		bullet.GetComponent<Rigidbody>().velocity = dir * speed;


		//parent
		bullet.transform.parent = bulletParent;
	}

	private void OnCollisionEnter(Collision collision) {
		
	}
}
