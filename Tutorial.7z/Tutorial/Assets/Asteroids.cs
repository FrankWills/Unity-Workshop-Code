﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroids : MonoBehaviour {

	private void OnCollisionEnter(Collision collision) {

		// IF Plyaer: do damage


		// Else:
		// Delete bullet
		Destroy(collision.gameObject);

		// Give the player some points

		// Create two smaller asteroids
		GameObject asteroid = Instantiate(this.gameObject);
		GameObject bsteroid = Instantiate(this.gameObject);

		asteroid.transform.localScale = this.transform.localScale * Random.Range(0.5f, 0.8f);
		bsteroid.transform.localScale = this.transform.localScale * Random.Range(0.5f, 0.8f);

		// Give random direction to float away
		Vector2 direction = Random.insideUnitCircle;
		direction.Normalize();

		Vector3 newDir = new Vector3(direction.x, 0, direction.y);

		asteroid.GetComponent<Rigidbody>().velocity = newDir;
		bsteroid.GetComponent<Rigidbody>().velocity = -newDir;

		GameObject.Destroy(this.gameObject);

	}

}
